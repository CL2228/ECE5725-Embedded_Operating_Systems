#!/bin/bash

python /home/pi/0923/more_video_control_cb.py &

sudo /home/pi/0923/run_video_with_fifo.sh

