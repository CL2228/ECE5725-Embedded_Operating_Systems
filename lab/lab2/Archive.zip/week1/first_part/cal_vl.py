import time


time.sleep(0.2)