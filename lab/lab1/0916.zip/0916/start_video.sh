#!/bin/bash


python /home/pi/0916/video_control.py &

sudo /home/pi/0916/run_video_with_fifo.sh

